How to run this torrent-like app:
I) Prepare step:
1) Run deal_torrent.py file to split video_sending.mp4 into pieces and create a new metainfo.torrent file
2) 1 server start running upload_metainfo.py file to send this metainfo.torrent file
3) other clients run download_metainfo.py and enter the URL of server to download metainfo.torrent file

II) Main step:
1) A server run tracker.py file
2) 1 client with full pieces (who just run deal_torrent.py) run client.py
3) Other clients run client.py file
4) After 100% downloaded, run merge.py to merge all the received pieces to final video_received.mp4 file.